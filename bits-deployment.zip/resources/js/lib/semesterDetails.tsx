export const smt = [
    'Odd Semester (2023/24)',
    'Even Semester (2023/24)',
    'Odd Semester (2024/25)',
    'Even Semester (2024/25)',
    'Odd Semester (2025/26)',
    'Even Semester (2025/26)',
    'Odd Semester (2026/27)',
    'Even Semester (2026/27)',
    'Odd Semester (2027/28)',
    'Even Semester (2027/28)',
] as const;
